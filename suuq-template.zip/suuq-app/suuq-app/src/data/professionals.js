import { API_BASE_URL } from "../config";

export const CATEGORIES = [
  "Entertainment",
  "F&B Consulting",
  "Event Production",
  "Digital Marketing",
  "Logistics",
  "Styling & Decor",
];

export const PROFESSIONALS = [
  {
    id: 'p1',
    name: 'Lina Haddad',
    title: 'Resident DJ & Music Curator',
    category: 'Entertainment',
    city: 'Dubai',
    rate: 4200,
    rating: 4.9,
    reviews: 38,
    verified: true,
    photo: 'https://i.pravatar.cc/300?img=47',
    bio: 'Ten years curating sets for rooftop lounges and beachfront launches across the UAE. Comfortable with open-format, deep house, and Arabic fusion sets.',
    skills: ['Live Mixing', 'Event Curation', 'Sound Setup'],
    gallery: [
      'https://images.unsplash.com/photo-1571266028243-d220c6e6c9a5?w=600',
      'https://images.unsplash.com/photo-1571935441005-15029a3c8e16?w=600',
    ],
  },
  {
    id: 'p2',
    name: 'Marcus Reyes',
    title: 'Executive Chef Consultant',
    category: 'F&B Consulting',
    city: 'Abu Dhabi',
    rate: 6500,
    rating: 4.8,
    reviews: 21,
    verified: true,
    photo: 'https://i.pravatar.cc/300?img=14',
    bio: 'Former group exec chef for two regional hotel chains. Now consults on menu engineering, kitchen workflow, and F&B cost control for new openings.',
    skills: ['Menu Design', 'Cost Control', 'Staff Training'],
    gallery: [
      'https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=600',
    ],
  },
  {
    id: 'p3',
    name: 'Sara Al Marzooqi',
    title: 'Event Production Lead',
    category: 'Event Production',
    city: 'Dubai',
    rate: 5200,
    rating: 4.7,
    reviews: 29,
    verified: true,
    photo: 'https://i.pravatar.cc/300?img=32',
    bio: 'Manages full-stack event logistics — vendor coordination, staging, AV, and on-site crew — for corporate launches and private functions.',
    skills: ['Vendor Management', 'On-site Production', 'Budgeting'],
    gallery: [
      'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600',
    ],
  },
  {
    id: 'p4',
    name: 'Tariq Osman',
    title: 'Growth & Social Strategist',
    category: 'Digital Marketing',
    city: 'Sharjah',
    rate: 3100,
    rating: 4.6,
    reviews: 17,
    verified: false,
    photo: 'https://i.pravatar.cc/300?img=51',
    bio: 'Builds content and paid-ads strategy for restaurant and lounge openings, with a focus on reservation conversion over vanity metrics.',
    skills: ['Paid Social', 'Content Strategy', 'Analytics'],
    gallery: [],
  },
  {
    id: 'p5',
    name: 'Yasmin Farouk',
    title: 'Floral & Event Stylist',
    category: 'Styling & Decor',
    city: 'Dubai',
    rate: 2800,
    rating: 5.0,
    reviews: 44,
    verified: true,
    photo: 'https://i.pravatar.cc/300?img=45',
    bio: 'Styling for weddings, brand activations, and restaurant launches — known for editorial-style floral installations on tight timelines.',
    skills: ['Floral Design', 'Set Styling', 'Brand Activations'],
    gallery: [
      'https://images.unsplash.com/photo-1478146896981-b80fe463b330?w=600',
    ],
  },
  {
    id: 'p6',
    name: 'Omar Khalil',
    title: 'Logistics & Fit-Out Coordinator',
    category: 'Logistics',
    city: 'Abu Dhabi',
    rate: 4000,
    rating: 4.5,
    reviews: 12,
    verified: true,
    photo: 'https://i.pravatar.cc/300?img=60',
    bio: 'Handles permits, supplier scheduling, and on-ground fit-out coordination for new restaurant and retail openings.',
    skills: ['Permit Handling', 'Supplier Sourcing', 'Fit-Out Scheduling'],
    gallery: [],
  },
];


const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const API_BASE = config?.backendUrl || config?.apiUrl || config?.baseUrl;

const useBackend = Boolean(API_BASE);

export async function fetchProfessionals({ category } = {}) {
  if (useBackend) {
    const url = new URL(`${API_BASE}/api/professionals`);

    if (category && category !== "All") {
      url.searchParams.set("category", category);
    }

    const response = await fetch(url.toString());

    if (!response.ok) {
      throw new Error("Failed to fetch professionals.");
    }

    return response.json();
  }

  await delay(250);

  if (!category || category === "All") {
    return PROFESSIONALS;
  }

  return PROFESSIONALS.filter((p) => p.category === category);
}

export async function fetchProfessionalById(id) {
  if (useBackend) {
    const response = await fetch(`${API_BASE}/api/professionals/${id}`);

    if (!response.ok) {
      throw new Error("Failed to fetch professional.");
    }

    return response.json();
  }

  await delay(200);

  return PROFESSIONALS.find((p) => p.id === id) || null;
}

export async function postTask(payload) {
  if (useBackend) {
    const response = await fetch(`${API_BASE}/api/tasks`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error("Failed to create task.");
    }

    return response.json();
  }

  await delay(300);

  return {
    id: `mock-task-${Date.now()}`,
    ...payload,
    status: "open",
  };
}