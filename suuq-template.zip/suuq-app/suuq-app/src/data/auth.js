import { API_BASE_URL } from "../config";

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const MOCK_USERS_KEY = "suuq_mock_users";

const hasBackend =
  typeof API_BASE_URL === "string" &&
  API_BASE_URL.trim() !== "";

function getStoredUsers() {
  const raw = localStorage.getItem(MOCK_USERS_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveStoredUsers(users) {
  localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
}

export async function registerUser(data) {
  if (hasBackend) {
    const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || "Registration failed.");
    }

    return result;
  }

  await delay(400);

  const users = getStoredUsers();

  if (users.some((user) => user.email === data.email)) {
    throw new Error("An account with this email already exists.");
  }

  const newUser = {
    id: `u-${Date.now()}`,
    ...data,
  };

  users.push(newUser);
  saveStoredUsers(users);

  return {
    user: {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
    },
    token: `mock-token-${newUser.id}`,
  };
}

export async function loginUser(data) {
  if (hasBackend) {
    const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || "Invalid email or password.");
    }

    return result;
  }

  await delay(400);

  const users = getStoredUsers();

  const found = users.find(
    (user) =>
      user.email === data.email &&
      user.password === data.password
  );

  if (!found) {
    throw new Error("Invalid email or password.");
  }

  return {
    user: {
      id: found.id,
      name: found.name,
      email: found.email,
      role: found.role,
    },
    token: `mock-token-${found.id}`,
  };
}

export async function requestPasswordReset(data) {
  if (hasBackend) {
    const response = await fetch(
      `${API_BASE_URL}/api/auth/forgot-password`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || "Request failed.");
    }

    return result;
  }

  await delay(400);

  return {
    message:
      "If that email exists in our system, a reset link has been sent.",
  };
}