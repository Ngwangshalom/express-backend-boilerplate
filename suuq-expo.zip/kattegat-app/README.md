# Kattegat — Expo + React Native Paper Starter

A bare-bones starter for the Kattegat app: Splash → Landing (2 sliders) →
Auth (Login / Register / Forgot password) → Main app (bottom tabs: Home,
Explore, Messages, Profile). Built with **Expo SDK 56**, **React Native
0.85.2**, **React 19.2.3**, React Navigation 7, and React Native Paper for
UI — all current as of this writing.

Everything renders from **mock data** by default — no backend required to
run it and click through every screen.

## Quick start

```bash
npm install
npx expo install --fix   # corrects any native dep versions to match your exact Expo SDK patch
npm start
```

Then press `i` (iOS simulator), `a` (Android emulator), or scan the QR code
with Expo Go.

> Heads up: SDK 56 assumes the New Architecture (`newArchEnabled: true` is
> set in `app.json`) and raises the iOS deployment target to 16.4 — you'll
> need Xcode 26.4+ to build for iOS locally. Always run
> `npx expo install --fix` right after `npm install` since Expo's own
> packages (expo-status-bar, expo-constants, etc.) get exact patch versions
> pinned per SDK release that drift quickly.


## Folder structure

```
App.tsx                     # entry point, providers (Paper + Navigation)
src/
  theme/                     # ← all design tokens live here
    colors.ts                #   palette (edit this to rebrand the app)
    spacing.ts               #   spacing & radius scale
    typography.ts            #   text styles
    theme.ts                 #   builds the Paper theme + Navigation theme
  navigation/
    types.ts                 # typed param lists for every navigator
    RootNavigator.tsx         # Splash -> Landing -> Auth -> Main
    AuthNavigator.tsx          # Login / Register / ForgotPassword stack
    MainTabNavigator.tsx      # bottom tabs, rendered with Paper's BottomNavigation.Bar
  screens/
    SplashScreen.tsx
    LandingScreen.tsx          # hero + both sliders + CTA
    auth/Login|Register|ForgotPassword
    main/Home|Explore|Messages|Profile
  components/
    BannerSlider.tsx           # slider #1 — autoplay-style promo carousel
    CategorySlider.tsx         # slider #2 — horizontal category chips
    FreelancerCard.tsx
  data/mockData.ts            # every mock dataset used across the app
  services/api.ts             # the backend-or-mock switch (see below)
  config/env.ts                # reads expo.extra.backendUrl
```

## Connecting a real backend (optional)

The app works fully offline on mock data. To point it at a real API:

1. Open `app.json`
2. Set `expo.extra.backendUrl` to your API base URL, e.g.:
   ```json
   "extra": { "backendUrl": "https://api.kattegat.app" }
   ```
3. That's it — `src/services/api.ts` checks `isBackendConfigured` and
   automatically switches every screen (auth, home feed, sliders, profile)
   from mock data to real `fetch` calls.

If you leave `backendUrl` empty, the app silently stays in mock mode — handy
for demos, design review, or App Store screenshots before the backend is
ready.

Adjust the endpoint paths/payloads inside `src/services/api.ts` to match
your real API contract (e.g. `/auth/login`, `/freelancers`, `/me`, etc.).

## Theming

Everything funnels through `src/theme/colors.ts`. Change the hex values
there and the header, buttons, tab bar, inputs, and cards re-theme
automatically (Paper theme + Navigation theme are both derived from the same
file in `src/theme/theme.ts`).

## Version notes (Expo SDK 56)

- **expo** `~56.0.0` → React Native `0.85.2`, React `19.2.3`, TypeScript `6.0.3` (Hermes v1 is the default JS engine).
- **react-native-paper** `^5.15.3` — confirmed compatible with RN 0.85 (the 5.15.x line shipped explicit RN 0.85 layout/portal fixes).
- **@react-navigation/native(-stack|bottom-tabs)** `^7.3.x` — native-stack v7 requires `react-native-screens` v4, which is pinned here.
- **react-native-gesture-handler** `^3.0.2` — v3 requires RN ≥ 0.82, satisfied by 0.85.
- `@expo/vector-icons` is on a deprecation path in SDK 56 in favor of scoped `@react-native-vector-icons/*` packages. It still works fine for this template; swap the imports in `src/navigation/MainTabNavigator.tsx` and `src/components/CategorySlider.tsx` later if you want to fully migrate.
- This template does **not** use Expo Router — it uses React Navigation directly, so the SDK 56 "Expo Router dropped React Navigation" breaking change doesn't affect it.

Because exact patch versions of Expo's own packages move fast between SDK releases, treat the versions above as accurate at the time of writing and always run `npx expo install --fix` after `npm install` to self-correct.

## Notes

- Bottom tab bar uses React Native Paper's `BottomNavigation.Bar` (not the
  default React Navigation tab bar) so the whole UI stays consistent with
  Paper components.
- Headers use native-stack with a shared `screenHeaderOptions` config so
  every screen gets the same header style for free — override per-screen via
  the `options` prop if needed.
- This is intentionally a *starter*: simple screens, mock data, no state
  management library, no persisted auth — wire in whatever you need
  (Zustand/Redux, SecureStore for tokens, etc.) as the app grows.

