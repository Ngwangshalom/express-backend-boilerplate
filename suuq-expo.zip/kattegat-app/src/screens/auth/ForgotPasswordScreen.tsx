// src/screens/auth/ForgotPasswordScreen.tsx
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, TextInput, Button } from 'react-native-paper';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '@/navigation/types';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';
import { api } from '@/services/api';

type Props = NativeStackScreenProps<AuthStackParamList, 'ForgotPassword'>;

export default function ForgotPasswordScreen({ navigation }: Props) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState<string | null>(null);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const res = await api.forgotPassword(email);
      setSent(res.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reset your password</Text>
      <Text style={styles.subtitle}>Enter your email and we'll send you a reset link</Text>

      <TextInput
        mode="outlined"
        label="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
        style={styles.input}
      />

      {sent && <Text style={styles.success}>{sent}</Text>}

      <Button mode="contained" buttonColor={colors.primary} onPress={handleSubmit} loading={loading} style={styles.button}>
        Send Reset Link
      </Button>

      <Button mode="text" onPress={() => navigation.navigate('Login')} style={styles.back}>
        Back to Sign In
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, backgroundColor: colors.background, justifyContent: 'center' },
  title: { fontSize: 24, fontWeight: '700', color: colors.textPrimary },
  subtitle: { fontSize: 14, color: colors.textSecondary, marginTop: 4, marginBottom: spacing.lg },
  input: { marginBottom: spacing.sm },
  success: { color: colors.success, fontSize: 13, marginBottom: spacing.sm },
  button: { borderRadius: 12, marginTop: spacing.xs, paddingVertical: 4 },
  back: { marginTop: spacing.sm },
});
