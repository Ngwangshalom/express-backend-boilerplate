// src/screens/main/ExploreScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Searchbar, ActivityIndicator } from 'react-native-paper';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';
import { api } from '@/services/api';
import { Freelancer } from '@/data/mockData';
import FreelancerCard from '@/components/FreelancerCard';

export default function ExploreScreen() {
  const [query, setQuery] = useState('');
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getFreelancers().then((data) => {
      setFreelancers(data);
      setLoading(false);
    });
  }, []);

  const filtered = freelancers.filter(
    (f) =>
      f.name.toLowerCase().includes(query.toLowerCase()) ||
      f.role.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Search freelancers or skills"
        value={query}
        onChangeText={setQuery}
        style={styles.search}
      />
      {loading ? (
        <ActivityIndicator color={colors.primary} style={{ marginTop: spacing.lg }} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => <FreelancerCard freelancer={item} />}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  search: { margin: spacing.md, backgroundColor: colors.surface },
  list: { paddingHorizontal: spacing.md, paddingBottom: spacing.xl },
});
