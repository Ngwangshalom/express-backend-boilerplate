// src/screens/main/HomeScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Text, ActivityIndicator } from 'react-native-paper';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';
import { api } from '@/services/api';
import { Banner, Category, Freelancer } from '@/data/mockData';
import BannerSlider from '@/components/BannerSlider';
import CategorySlider from '@/components/CategorySlider';
import FreelancerCard from '@/components/FreelancerCard';

export default function HomeScreen() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [b, c, f] = await Promise.all([api.getBanners(), api.getCategories(), api.getFreelancers()]);
      setBanners(b);
      setCategories(c);
      setFreelancers(f);
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <BannerSlider banners={banners} />
      <Text style={styles.sectionTitle}>Categories</Text>
      <CategorySlider categories={categories} />
      <Text style={styles.sectionTitle}>Recommended for you</Text>
      {freelancers.map((f) => (
        <FreelancerCard key={f.id} freelancer={f} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.md, paddingBottom: spacing.xl },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: colors.textPrimary, marginTop: spacing.lg, marginBottom: spacing.sm },
});
