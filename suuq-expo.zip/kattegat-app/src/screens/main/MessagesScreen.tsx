// src/screens/main/MessagesScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Text, Avatar, Divider, ActivityIndicator } from 'react-native-paper';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';
import { api } from '@/services/api';
import { Message } from '@/data/mockData';

export default function MessagesScreen() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getMessages().then((data) => {
      setMessages(data);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      data={messages}
      keyExtractor={(item) => item.id}
      ItemSeparatorComponent={() => <Divider />}
      renderItem={({ item }) => (
        <View style={styles.row}>
          <Avatar.Text size={44} label={item.name.slice(0, 2).toUpperCase()} style={{ backgroundColor: colors.primaryLight }} />
          <View style={styles.info}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.preview} numberOfLines={1}>{item.preview}</Text>
          </View>
          <View style={styles.meta}>
            <Text style={styles.time}>{item.time}</Text>
            {item.unread && <View style={styles.dot} />}
          </View>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  row: { flexDirection: 'row', alignItems: 'center', padding: spacing.md },
  info: { flex: 1, marginLeft: spacing.sm },
  name: { fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  preview: { fontSize: 13, color: colors.textSecondary, marginTop: 2 },
  meta: { alignItems: 'flex-end' },
  time: { fontSize: 11, color: colors.textSecondary },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.accent, marginTop: 6 },
});
