// src/screens/main/ProfileScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text, Avatar, List, Button, ActivityIndicator } from 'react-native-paper';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { MainTabParamList, RootStackParamList } from '@/navigation/types';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';
import { api } from '@/services/api';
import { User } from '@/data/mockData';

type Props = CompositeScreenProps<
  BottomTabScreenProps<MainTabParamList, 'Profile'>,
  NativeStackScreenProps<RootStackParamList>
>;

export default function ProfileScreen({ navigation }: Props) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    api.getProfile().then(setUser);
  }, []);

  if (!user) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Avatar.Text size={64} label={user.name.slice(0, 2).toUpperCase()} style={{ backgroundColor: colors.accent }} />
        <Text style={styles.name}>{user.name}</Text>
        <Text style={styles.email}>{user.email}</Text>
        <Text style={styles.role}>{user.role}</Text>
      </View>

      <List.Section>
        <List.Item title="Edit profile" left={(p) => <List.Icon {...p} icon="account-edit-outline" />} />
        <List.Item title="My listings" left={(p) => <List.Icon {...p} icon="briefcase-outline" />} />
        <List.Item title="Payments" left={(p) => <List.Icon {...p} icon="credit-card-outline" />} />
        <List.Item title="Notifications" left={(p) => <List.Icon {...p} icon="bell-outline" />} />
        <List.Item title="Help & support" left={(p) => <List.Icon {...p} icon="help-circle-outline" />} />
      </List.Section>

      <Button
        mode="outlined"
        textColor={colors.error}
        style={styles.logout}
        onPress={() => navigation.getParent()?.navigate('Landing')}
      >
        Log Out
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.surface },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  header: { alignItems: 'center', padding: spacing.lg },
  name: { fontSize: 18, fontWeight: '700', color: colors.textPrimary, marginTop: spacing.sm },
  email: { fontSize: 13, color: colors.textSecondary, marginTop: 2 },
  role: { fontSize: 12, color: colors.primary, fontWeight: '600', marginTop: 6 },
  logout: { margin: spacing.lg, borderColor: colors.error },
});
