// src/screens/LandingScreen.tsx
import React, { useEffect, useState } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { Text, Button, ActivityIndicator } from 'react-native-paper';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';
import { api } from '@/services/api';
import { Banner, Category, Freelancer } from '@/data/mockData';
import BannerSlider from '@/components/BannerSlider';
import CategorySlider from '@/components/CategorySlider';
import FreelancerCard from '@/components/FreelancerCard';

type Props = NativeStackScreenProps<RootStackParamList, 'Landing'>;

export default function LandingScreen({ navigation }: Props) {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [b, c, f] = await Promise.all([
        api.getBanners(),
        api.getCategories(),
        api.getFreelancers(),
      ]);
      setBanners(b);
      setCategories(c);
      setFreelancers(f.slice(0, 3));
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.brand}>Kattegat</Text>
        <Text style={styles.heading}>Hire the best hospitality{'\n'}talent in the UAE</Text>

        {/* Slider 1: promo banners */}
        <BannerSlider banners={banners} />

        <Text style={styles.sectionTitle}>Browse categories</Text>
        {/* Slider 2: categories */}
        <CategorySlider categories={categories} />

        <Text style={styles.sectionTitle}>Top freelancers</Text>
        {freelancers.map((f) => (
          <FreelancerCard key={f.id} freelancer={f} />
        ))}
      </ScrollView>

      <View style={styles.ctaRow}>
        <Button
          mode="contained"
          buttonColor={colors.primary}
          style={styles.ctaButton}
          onPress={() => navigation.navigate('Auth', { screen: 'Register' })}
        >
          Get Started
        </Button>
        <Button mode="text" textColor={colors.primary} onPress={() => navigation.navigate('Auth', { screen: 'Login' })}>
          I already have an account
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  scrollContent: { padding: spacing.md, paddingBottom: spacing.xl },
  brand: { fontSize: 14, fontWeight: '700', color: colors.accentDark, letterSpacing: 1 },
  heading: { fontSize: 24, fontWeight: '700', color: colors.textPrimary, marginTop: 4, marginBottom: spacing.md },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: colors.textPrimary, marginTop: spacing.lg, marginBottom: spacing.sm },
  ctaRow: { padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.surface },
  ctaButton: { borderRadius: 12, marginBottom: spacing.xs },
});
