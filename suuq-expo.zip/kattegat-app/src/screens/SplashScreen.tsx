// src/screens/SplashScreen.tsx
import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { colors } from '@/theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Splash'>;

export default function SplashScreen({ navigation }: Props) {
  useEffect(() => {
    // Swap this timer for a real bootstrap step later (check stored auth
    // token, fetch remote config, etc.) then navigate accordingly.
    const timer = setTimeout(() => {
      navigation.replace('Landing');
    }, 1400);
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.logoCircle}>
        <MaterialCommunityIcons name="anchor" size={40} color={colors.accent} />
      </View>
      <Text style={styles.title}>Kattegat</Text>
      <Text style={styles.subtitle}>Hospitality talent, vetted & ready</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoCircle: {
    width: 84,
    height: 84,
    borderRadius: 42,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  title: { color: colors.textOnPrimary, fontSize: 28, fontWeight: '700', letterSpacing: 0.5 },
  subtitle: { color: colors.textOnPrimary, fontSize: 13, opacity: 0.75, marginTop: 6 },
});
