// src/navigation/MainTabNavigator.tsx
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { BottomNavigation } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { MainTabParamList } from './types';
import { screenHeaderOptions } from '@/theme/theme';
import { colors } from '@/theme/colors';

import HomeScreen from '@/screens/main/HomeScreen';
import ExploreScreen from '@/screens/main/ExploreScreen';
import MessagesScreen from '@/screens/main/MessagesScreen';
import ProfileScreen from '@/screens/main/ProfileScreen';

const Tab = createBottomTabNavigator<MainTabParamList>();

const TAB_ICONS: Record<keyof MainTabParamList, string> = {
  Home: 'home-variant',
  Explore: 'compass-outline',
  Messages: 'message-text-outline',
  Profile: 'account-circle-outline',
};

export default function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={screenHeaderOptions}
      // Render React Native Paper's BottomNavigation.Bar instead of the
      // default RN Navigation tab bar, so the whole app stays on Paper's UI.
      tabBar={({ navigation, state, descriptors, insets }) => (
        <BottomNavigation.Bar
          navigationState={state}
          safeAreaInsets={insets}
          activeColor={colors.primary}
          inactiveColor={colors.tabInactive}
          style={{ backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border }}
          onTabPress={({ route, preventDefault }) => {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });
            if (event.defaultPrevented) {
              preventDefault();
            } else {
              navigation.navigate(route.name as never);
            }
          }}
          renderIcon={({ route, focused, color }) => (
            <MaterialCommunityIcons
              name={TAB_ICONS[route.name as keyof MainTabParamList] as any}
              size={24}
              color={color}
              style={{ opacity: focused ? 1 : 0.8 }}
            />
          )}
          getLabelText={({ route }) => descriptors[route.key].options.title ?? route.name}
        />
      )}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: 'Home' }} />
      <Tab.Screen name="Explore" component={ExploreScreen} options={{ title: 'Explore' }} />
      <Tab.Screen name="Messages" component={MessagesScreen} options={{ title: 'Messages' }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}
