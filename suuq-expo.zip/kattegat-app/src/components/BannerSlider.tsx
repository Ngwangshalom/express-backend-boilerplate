// src/components/BannerSlider.tsx
import React, { useRef, useState } from 'react';
import { View, FlatList, StyleSheet, Dimensions, NativeSyntheticEvent, NativeScrollEvent } from 'react-native';
import { Text } from 'react-native-paper';
import { Banner } from '@/data/mockData';
import { colors } from '@/theme/colors';
import { radius, spacing } from '@/theme/spacing';

const { width } = Dimensions.get('window');
const SLIDE_WIDTH = width - spacing.md * 2;

type Props = { banners: Banner[] };

export default function BannerSlider({ banners }: Props) {
  const [activeIndex, setActiveIndex] = useState(0);
  const listRef = useRef<FlatList<Banner>>(null);

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const index = Math.round(e.nativeEvent.contentOffset.x / SLIDE_WIDTH);
    setActiveIndex(index);
  };

  return (
    <View>
      <FlatList
        ref={listRef}
        data={banners}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.slide, { backgroundColor: item.color }]}>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.subtitle}>{item.subtitle}</Text>
          </View>
        )}
      />
      <View style={styles.dots}>
        {banners.map((b, i) => (
          <View key={b.id} style={[styles.dot, i === activeIndex && styles.dotActive]} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  slide: {
    width: SLIDE_WIDTH,
    height: 150,
    borderRadius: radius.lg,
    padding: spacing.lg,
    justifyContent: 'center',
  },
  title: { color: colors.textOnPrimary, fontSize: 18, fontWeight: '700', marginBottom: spacing.xs },
  subtitle: { color: colors.textOnPrimary, fontSize: 13, opacity: 0.85 },
  dots: { flexDirection: 'row', justifyContent: 'center', marginTop: spacing.sm },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.border,
    marginHorizontal: 3,
  },
  dotActive: { backgroundColor: colors.accent, width: 16 },
});
