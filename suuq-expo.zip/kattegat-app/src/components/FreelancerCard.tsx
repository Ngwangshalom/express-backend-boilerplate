// src/components/FreelancerCard.tsx
import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Avatar, Card } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Freelancer } from '@/data/mockData';
import { colors } from '@/theme/colors';
import { spacing } from '@/theme/spacing';

type Props = { freelancer: Freelancer };

export default function FreelancerCard({ freelancer }: Props) {
  const initials = freelancer.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .slice(0, 2);

  return (
    <Card style={styles.card} mode="contained">
      <Card.Content style={styles.row}>
        <Avatar.Text size={48} label={initials} style={{ backgroundColor: freelancer.avatarColor }} />
        <View style={styles.info}>
          <Text style={styles.name}>{freelancer.name}</Text>
          <Text style={styles.role}>{freelancer.role}</Text>
          <View style={styles.metaRow}>
            <MaterialCommunityIcons name="star" size={14} color={colors.accent} />
            <Text style={styles.meta}>
              {freelancer.rating.toFixed(1)} ({freelancer.reviews})
            </Text>
            <Text style={styles.dotSep}>•</Text>
            <Text style={styles.meta}>{freelancer.location}</Text>
          </View>
        </View>
        <Text style={styles.rate}>{freelancer.rate}</Text>
      </Card.Content>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: { marginBottom: spacing.sm, backgroundColor: colors.surface },
  row: { flexDirection: 'row', alignItems: 'center' },
  info: { flex: 1, marginLeft: spacing.sm },
  name: { fontSize: 15, fontWeight: '700', color: colors.textPrimary },
  role: { fontSize: 13, color: colors.textSecondary, marginTop: 2 },
  metaRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  meta: { fontSize: 12, color: colors.textSecondary, marginLeft: 3 },
  dotSep: { marginHorizontal: 5, color: colors.textSecondary },
  rate: { fontSize: 12, fontWeight: '700', color: colors.primary, marginLeft: spacing.sm },
});
