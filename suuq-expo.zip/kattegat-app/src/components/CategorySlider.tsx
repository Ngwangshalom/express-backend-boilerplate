// src/components/CategorySlider.tsx
import React from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Category } from '@/data/mockData';
import { colors } from '@/theme/colors';
import { radius, spacing } from '@/theme/spacing';

type Props = { categories: Category[] };

export default function CategorySlider({ categories }: Props) {
  return (
    <FlatList
      data={categories}
      horizontal
      showsHorizontalScrollIndicator={false}
      keyExtractor={(item) => item.id}
      contentContainerStyle={{ paddingRight: spacing.md }}
      renderItem={({ item }) => (
        <View style={styles.card}>
          <View style={styles.iconWrap}>
            <MaterialCommunityIcons name={item.icon as any} size={22} color={colors.primary} />
          </View>
          <Text style={styles.label}>{item.name}</Text>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  card: {
    width: 96,
    alignItems: 'center',
    marginRight: spacing.sm,
    paddingVertical: spacing.sm,
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: radius.lg,
    backgroundColor: colors.surfaceMuted,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  label: { fontSize: 12, color: colors.textSecondary, textAlign: 'center' },
});
