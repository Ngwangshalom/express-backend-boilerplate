// src/services/api.ts
//
// Every function below follows the same rule:
//   if (isBackendConfigured) hit the real API
//   else                     resolve with mock data
//
// This means screens never need to know which mode they're in — they just
// call `api.getHomeFeed()` etc. To go live, set expo.extra.backendUrl in
// app.json and (optionally) adjust the endpoint paths/payloads below to
// match your actual API contract.

import { BACKEND_URL, isBackendConfigured } from '@/config/env';
import {
  mockBanners,
  mockCategories,
  mockFreelancers,
  mockMessages,
  mockUser,
  Banner,
  Category,
  Freelancer,
  Message,
  User,
} from '@/data/mockData';

const MOCK_DELAY = 350;

function delay<T>(value: T, ms = MOCK_DELAY): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${BACKEND_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  if (!res.ok) {
    throw new Error(`Request failed (${res.status}): ${path}`);
  }
  return res.json() as Promise<T>;
}

export type AuthResponse = { token: string; user: User };

export const api = {
  // ---- Home feed (landing sliders) ----
  async getBanners(): Promise<Banner[]> {
    if (!isBackendConfigured) return delay(mockBanners);
    return request<Banner[]>('/banners');
  },

  async getCategories(): Promise<Category[]> {
    if (!isBackendConfigured) return delay(mockCategories);
    return request<Category[]>('/categories');
  },

  async getFreelancers(): Promise<Freelancer[]> {
    if (!isBackendConfigured) return delay(mockFreelancers);
    return request<Freelancer[]>('/freelancers');
  },

  async getMessages(): Promise<Message[]> {
    if (!isBackendConfigured) return delay(mockMessages);
    return request<Message[]>('/messages');
  },

  async getProfile(): Promise<User> {
    if (!isBackendConfigured) return delay(mockUser);
    return request<User>('/me');
  },

  // ---- Auth ----
  async login(email: string, password: string): Promise<AuthResponse> {
    if (!isBackendConfigured) {
      return delay({ token: 'mock-token', user: { ...mockUser, email } });
    }
    return request<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  async register(name: string, email: string, password: string): Promise<AuthResponse> {
    if (!isBackendConfigured) {
      return delay({ token: 'mock-token', user: { ...mockUser, name, email } });
    }
    return request<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
  },

  async forgotPassword(email: string): Promise<{ message: string }> {
    if (!isBackendConfigured) {
      return delay({ message: `Mock mode: reset link "sent" to ${email}` });
    }
    return request<{ message: string }>('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },
};
