// src/theme/theme.ts
//
// Single source of truth for theming. Both React Native Paper and
// React Navigation pull their colors from here, so changing colors.ts
// re-themes the whole app (headers, tab bar, buttons, inputs) at once.

import { MD3LightTheme, adaptNavigationTheme } from 'react-native-paper';
import { DefaultTheme as NavigationDefaultTheme } from '@react-navigation/native';
import { colors } from './colors';

export const paperTheme = {
  ...MD3LightTheme,
  colors: {
    ...MD3LightTheme.colors,
    primary: colors.primary,
    onPrimary: colors.textOnPrimary,
    secondary: colors.accent,
    onSecondary: colors.textOnAccent,
    background: colors.background,
    surface: colors.surface,
    surfaceVariant: colors.surfaceMuted,
    onSurface: colors.textPrimary,
    onSurfaceVariant: colors.textSecondary,
    error: colors.error,
    outline: colors.border,
  },
  roundness: 12,
};

const { LightTheme } = adaptNavigationTheme({ reactNavigationLight: NavigationDefaultTheme });

export const navigationTheme = {
  ...LightTheme,
  colors: {
    ...LightTheme.colors,
    primary: colors.primary,
    background: colors.background,
    card: colors.surface,
    text: colors.textPrimary,
    border: colors.border,
    notification: colors.accent,
  },
};

// Shared options for native-stack headers so every screen looks consistent.
export const screenHeaderOptions = {
  headerStyle: { backgroundColor: colors.primary },
  headerTintColor: colors.textOnPrimary,
  headerTitleStyle: { fontWeight: '700' as const },
  headerShadowVisible: false,
};
