// src/theme/colors.ts
//
// Kattegat is named after the strait between Denmark and Sweden — so the
// palette leans nautical: deep navy "water", warm amber "beacon" accent,
// and a clean fog-grey background. Swap these to rebrand the whole app.

export const colors = {
  // Brand
  primary: '#0B2545', // deep navy — headers, primary buttons, active tab
  primaryDark: '#06182F',
  primaryLight: '#1B3A63',

  accent: '#D9A24B', // amber beacon — CTAs, highlights, ratings
  accentDark: '#B97F2E',
  accentLight: '#F0C77E',

  // Surfaces
  background: '#F6F7FA',
  surface: '#FFFFFF',
  surfaceMuted: '#EEF1F6',

  // Text
  textPrimary: '#0F1C2E',
  textSecondary: '#5B6776',
  textOnPrimary: '#FFFFFF',
  textOnAccent: '#1A1303',

  // Utility
  border: '#E1E5EB',
  success: '#2E9E6B',
  warning: '#D9A24B',
  error: '#C24545',

  // Tab bar
  tabInactive: '#9AA5B1',
};

export type AppColors = typeof colors;
