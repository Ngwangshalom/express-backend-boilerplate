// src/config/env.ts
import Constants from 'expo-constants';

// Reads expo.extra.backendUrl from app.json. Empty string / undefined means
// "no backend yet" — every service in src/services should fall back to
// mock data in that case. This is the ONLY switch you need to flip.
const extra = (Constants.expoConfig?.extra ?? {}) as { backendUrl?: string };

export const BACKEND_URL = (extra.backendUrl ?? '').trim();

export const isBackendConfigured = BACKEND_URL.length > 0;
