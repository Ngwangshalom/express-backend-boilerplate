// src/data/mockData.ts
//
// Central mock dataset. Shapes here mirror what a real API would return,
// so swapping in real endpoints in src/services/api.ts later is a drop-in.

export type Banner = {
  id: string;
  title: string;
  subtitle: string;
  color: string;
};

export type Category = {
  id: string;
  name: string;
  icon: string; // MaterialCommunityIcons name
};

export type Freelancer = {
  id: string;
  name: string;
  role: string;
  rating: number;
  reviews: number;
  rate: string;
  location: string;
  avatarColor: string;
};

export type Message = {
  id: string;
  name: string;
  preview: string;
  time: string;
  unread: boolean;
};

export type User = {
  id: string;
  name: string;
  email: string;
  role: 'Freelancer' | 'Employer';
};

// Slider #1 — promo banners (landing screen hero carousel)
export const mockBanners: Banner[] = [
  {
    id: 'b1',
    title: 'Find vetted hospitality talent',
    subtitle: 'Hire freelancers & subcontractors across the UAE',
    color: '#0B2545',
  },
  {
    id: 'b2',
    title: 'List your services in minutes',
    subtitle: 'Get discovered by hotels, restaurants & event planners',
    color: '#1B3A63',
  },
  {
    id: 'b3',
    title: '4,000+ verified professionals',
    subtitle: 'From DJs to consultants — all vetted, all trusted',
    color: '#B97F2E',
  },
];

// Slider #2 — categories (horizontal chip/card carousel)
export const mockCategories: Category[] = [
  { id: 'c1', name: 'F&B Consulting', icon: 'silverware-fork-knife' },
  { id: 'c2', name: 'Event Production', icon: 'calendar-star' },
  { id: 'c3', name: 'Entertainment', icon: 'music' },
  { id: 'c4', name: 'Digital Marketing', icon: 'bullhorn-outline' },
  { id: 'c5', name: 'Logistics', icon: 'truck-outline' },
  { id: 'c6', name: 'Training', icon: 'school-outline' },
];

export const mockFreelancers: Freelancer[] = [
  { id: 'f1', name: 'Sari Sater', role: 'Digital Marketing Strategist', rating: 5.0, reviews: 1, rate: 'AED 7,000/hr', location: 'Dubai, UAE', avatarColor: '#D9A24B' },
  { id: 'f2', name: 'Taya Kruzz', role: 'DJ & Live Entertainment', rating: 4.8, reviews: 12, rate: 'AED 4,500/hr', location: 'Abu Dhabi, UAE', avatarColor: '#1B3A63' },
  { id: 'f3', name: 'Rajan Rengasamy', role: 'F&B Expert', rating: 4.6, reviews: 9, rate: 'AED 3,500/hr', location: 'Sharjah, UAE', avatarColor: '#2E9E6B' },
  { id: 'f4', name: 'Alex Hayek', role: 'Premium Saxophonist', rating: 4.9, reviews: 21, rate: 'AED 2,750/hr', location: 'Dubai, UAE', avatarColor: '#C24545' },
  { id: 'f5', name: 'Mona Idris', role: 'Event Producer', rating: 4.7, reviews: 15, rate: 'AED 5,200/hr', location: 'Dubai, UAE', avatarColor: '#B97F2E' },
];

export const mockMessages: Message[] = [
  { id: 'm1', name: 'Sari Sater', preview: 'Sounds good, see you at the venue!', time: '09:42', unread: true },
  { id: 'm2', name: 'Mona Idris', preview: 'I sent the updated proposal.', time: 'Yesterday', unread: false },
  { id: 'm3', name: 'Support Team', preview: 'Your task has been approved ✅', time: 'Mon', unread: false },
];

export const mockUser: User = {
  id: 'u1',
  name: 'Ngwang Shalom',
  email: 'shalom@kattegat.app',
  role: 'Freelancer',
};
