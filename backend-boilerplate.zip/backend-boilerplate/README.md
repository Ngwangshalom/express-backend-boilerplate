# Backend Boilerplate — Express + MongoDB (Mongoose)

A minimal, fast-to-understand backend starter for Express + MongoDB. Built for quick builds, demos, and technical interviews — no auth, no extra layers, just a clean working API you can extend in minutes.

## Stack

- **Express** — server & routing
- **Mongoose** — MongoDB ODM (schemas, validation, queries)
- **MongoDB Atlas** — hosted database (free tier works fine)
- **dotenv** — environment variables
- **cors** — allows your React / React Native apps to call this API
- **nodemon** (dev only) — auto-restarts server on file changes

## Folder structure

```
backend-boilerplate/
├── config/
│   └── db.js              # MongoDB connection logic
├── controllers/
│   └── userController.js  # Request handlers (business logic)
├── models/
│   └── User.js            # Mongoose schema/model
├── routes/
│   └── userRoutes.js      # Express routes → controller mapping
├── .env.example           # Template for your environment variables
├── .gitignore
├── package.json
└── server.js               # App entry point
```

This follows a simple **Model → Controller → Route** pattern:
- **Model** defines the data shape (Mongoose schema)
- **Controller** contains the logic for each request (get, create, update, delete)
- **Route** maps a URL + HTTP method to a controller function

To add a new resource (e.g. `Product`), copy `User.js` → `Product.js`, `userController.js` → `productController.js`, `userRoutes.js` → `productRoutes.js`, adjust the fields/logic, then register it in `server.js`.

---

## Setup instructions

### 1. Clone the repo

```bash
git clone https://github.com/<your-username>/backend-boilerplate.git
cd backend-boilerplate
```

### 2. Install dependencies

```bash
npm install
```

This installs everything listed in `package.json` (express, mongoose, dotenv, cors, nodemon).

### 3. Set up MongoDB Atlas (if you don't already have a cluster)

1. Go to mongodb.com/cloud/atlas and sign in / sign up
2. Create a free (M0) cluster
3. Under **Database Access**, create a database user with a username + password
4. Under **Network Access**, add your IP (or `0.0.0.0/0` to allow access from anywhere — fine for development/demos)
5. Click **Connect** → **Drivers** → copy the connection string, it'll look like:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/myDatabase
   ```

### 4. Configure environment variables

Copy the example file and fill in your own values:

```bash
cp .env.example .env
```

Edit `.env`:

```
PORT=5000
MONGO_URI=mongodb+srv://yourUsername:yourPassword@cluster0.xxxxx.mongodb.net/myDatabase
```

### 5. Run the server

For development (auto-restarts on save):

```bash
npm run dev
```

For a plain run:

```bash
npm start
```

You should see:

```
✅ MongoDB connected
🚀 Server running on port 5000
```

### 6. Test it

Visit `http://localhost:5000` in your browser — you should see `API is running ✅`.

Try the example User API with curl, Postman, or Thunder Client:

```bash
# Create a user
curl -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "Ngwang", "email": "ngwang@example.com"}'

# Get all users
curl http://localhost:5000/api/users
```

---

## Connecting your frontend

### From React (web)

```js
fetch('http://localhost:5000/api/users')
  .then((res) => res.json())
  .then((data) => console.log(data));
```

### From React Native (Expo)

`localhost` does **not** work the same way on mobile — use the right host depending on where you're running it:

| Environment | Use this as your base URL |
|---|---|
| iOS Simulator | `http://localhost:5000` |
| Android Emulator | `http://10.0.2.2:5000` |
| Physical device (same WiFi as your laptop) | `http://<your-laptop-local-IP>:5000` |

Find your laptop's local IP:
- Mac: `ipconfig getifaddr en0`
- Windows: `ipconfig` (look for IPv4 Address)

Example:

```js
fetch('http://192.168.1.15:5000/api/users')
  .then((res) => res.json())
  .then((data) => console.log(data));
```

Make sure your phone and laptop are on the **same WiFi network**, and that your firewall isn't blocking the port.

---

## API Reference (example User resource)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/users` | Get all users |
| GET | `/api/users/:id` | Get a single user by ID |
| POST | `/api/users` | Create a new user |
| PUT | `/api/users/:id` | Update a user |
| DELETE | `/api/users/:id` | Delete a user |

---

## Notes

- No authentication is included by default — this is intentional, to keep the boilerplate fast to read and extend under time pressure. Add JWT/Passport only if your task requires it.
- Error handling is minimal but present (404 + global error handler in `server.js`) so the app doesn't crash silently.
- Swap `User` for whatever resource your task needs — the pattern stays identical.

## License

MIT — use freely for personal projects, interviews, or production starters.
