const express = require('express');
const router = express.Router();
const {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
} = require('../controllers/userController');
// const { protect } = require('../middleware/authMiddleware');
// To protect any of these routes, add `protect` as middleware, e.g.:
//   router.get('/', protect, getUsers);

router.get('/', getUsers);
router.get('/:id', getUserById);
router.post('/', createUser);
router.put('/:id', updateUser);
router.delete('/:id', deleteUser);

module.exports = router;
