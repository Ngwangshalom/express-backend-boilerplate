# Kattegat — Expo + React Native Paper Starter

A bare-bones starter for the Kattegat app: Splash → Landing (2 sliders) →
Auth (Login / Register / Forgot password) → Main app (bottom tabs: Home,
Explore, Messages, Profile). Built with Expo, React Navigation, and React
Native Paper for UI.

Everything renders from **mock data** by default — no backend required to
run it and click through every screen.

## Quick start

```bash
npm install
npx expo install   # makes sure native module versions match your Expo SDK
npm start
```

Then press `i` (iOS simulator), `a` (Android emulator), or scan the QR code
with Expo Go.

## Folder structure

```
App.tsx                     # entry point, providers (Paper + Navigation)
src/
  theme/                     # ← all design tokens live here
    colors.ts                #   palette (edit this to rebrand the app)
    spacing.ts               #   spacing & radius scale
    typography.ts            #   text styles
    theme.ts                 #   builds the Paper theme + Navigation theme
  navigation/
    types.ts                 # typed param lists for every navigator
    RootNavigator.tsx         # Splash -> Landing -> Auth -> Main
    AuthNavigator.tsx          # Login / Register / ForgotPassword stack
    MainTabNavigator.tsx      # bottom tabs, rendered with Paper's BottomNavigation.Bar
  screens/
    SplashScreen.tsx
    LandingScreen.tsx          # hero + both sliders + CTA
    auth/Login|Register|ForgotPassword
    main/Home|Explore|Messages|Profile
  components/
    BannerSlider.tsx           # slider #1 — autoplay-style promo carousel
    CategorySlider.tsx         # slider #2 — horizontal category chips
    FreelancerCard.tsx
  data/mockData.ts            # every mock dataset used across the app
  services/api.ts             # the backend-or-mock switch (see below)
  config/env.ts                # reads expo.extra.backendUrl
```

## Connecting a real backend (optional)

The app works fully offline on mock data. To point it at a real API:

1. Open `app.json`
2. Set `expo.extra.backendUrl` to your API base URL, e.g.:
   ```json
   "extra": { "backendUrl": "https://api.kattegat.app" }
   ```
3. That's it — `src/services/api.ts` checks `isBackendConfigured` and
   automatically switches every screen (auth, home feed, sliders, profile)
   from mock data to real `fetch` calls.

If you leave `backendUrl` empty, the app silently stays in mock mode — handy
for demos, design review, or App Store screenshots before the backend is
ready.

Adjust the endpoint paths/payloads inside `src/services/api.ts` to match
your real API contract (e.g. `/auth/login`, `/freelancers`, `/me`, etc.).

## Theming

Everything funnels through `src/theme/colors.ts`. Change the hex values
there and the header, buttons, tab bar, inputs, and cards re-theme
automatically (Paper theme + Navigation theme are both derived from the same
file in `src/theme/theme.ts`).

## Notes

- Bottom tab bar uses React Native Paper's `BottomNavigation.Bar` (not the
  default React Navigation tab bar) so the whole UI stays consistent with
  Paper components.
- Headers use native-stack with a shared `screenHeaderOptions` config so
  every screen gets the same header style for free — override per-screen via
  the `options` prop if needed.
- This is intentionally a *starter*: simple screens, mock data, no state
  management library, no persisted auth — wire in whatever you need
  (Zustand/Redux, SecureStore for tokens, etc.) as the app grows.
