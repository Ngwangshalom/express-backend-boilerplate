// API CONFIGURATION
//
// This project currently runs entirely on mock data (see src/data/professionals.js
// and src/data/auth.js) so the UI works standalone with zero backend setup.
//
// When your backend is ready:
// 1. Set API_BASE_URL below to your real backend URL.
// 2. In src/data/professionals.js and src/data/auth.js, replace the mock function
//    bodies with real `fetch(...)` calls using API_BASE_URL — the function names
//    and what they return should stay the same, so no other file needs to change.
//
// Example of what a real call would look like:
//
//   export async function fetchProfessionals({ category } = {}) {
//     const url = category && category !== 'All'
//       ? `${API_BASE_URL}/api/professionals?category=${encodeURIComponent(category)}`
//       : `${API_BASE_URL}/api/professionals`;
//     const res = await fetch(url);
//     if (!res.ok) throw new Error('Failed to fetch professionals');
//     return res.json();
//   }

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000';
