import { createTheme } from '@mantine/core';

export const theme = createTheme({
  fontFamily: 'Inter, system-ui, sans-serif',
  headings: {
    fontFamily: 'Sora, system-ui, sans-serif',
    fontWeight: '700',
  },
  primaryColor: 'teal',
  colors: {
    teal: [
      '#E6F0F2', '#C2DBE0', '#9CC5CD', '#74AFB9', '#4F99A6',
      '#2C8493', '#0F4C5C', '#0C3D49', '#092E37', '#061F25',
    ],
    terracotta: [
      '#FBEFE9', '#F5D5C5', '#EFBAA0', '#E99E7A', '#E38356',
      '#D97757', '#C2603F', '#9C4D33', '#763A27', '#50271A',
    ],
  },
  defaultRadius: 'md',
  components: {
    Button: {
      defaultProps: {
        radius: 'md',
      },
    },
    Card: {
      defaultProps: {
        radius: 'lg',
      },
    },
  },
});
