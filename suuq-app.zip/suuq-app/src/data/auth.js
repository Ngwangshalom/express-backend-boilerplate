// MOCK AUTH — replace these with real calls to your backend, e.g.:
//   fetch(`${API_BASE_URL}/api/auth/login`, { method: 'POST', body: JSON.stringify({ email, password }) })
// The shape of what's returned (a user object + token) is what your real backend should also return,
// so the rest of the app (AuthContext) doesn't need to change when you wire in the real API.

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const MOCK_USERS_KEY = 'suuq_mock_users';

function getStoredUsers() {
  const raw = localStorage.getItem(MOCK_USERS_KEY);
  return raw ? JSON.parse(raw) : [];
}

function saveStoredUsers(users) {
  localStorage.setItem(MOCK_USERS_KEY, JSON.stringify(users));
}

/**
 * REPLACE WITH: POST /api/auth/register
 */
export async function registerUser({ name, email, password, role }) {
  await delay(400);
  const users = getStoredUsers();

  if (users.some((u) => u.email === email)) {
    throw new Error('An account with this email already exists.');
  }

  const newUser = { id: 'u-' + Date.now(), name, email, role, password };
  users.push(newUser);
  saveStoredUsers(users);

  return { user: { id: newUser.id, name, email, role }, token: 'mock-token-' + newUser.id };
}

/**
 * REPLACE WITH: POST /api/auth/login
 */
export async function loginUser({ email, password }) {
  await delay(400);
  const users = getStoredUsers();
  const found = users.find((u) => u.email === email && u.password === password);

  if (!found) {
    throw new Error('Invalid email or password.');
  }

  return {
    user: { id: found.id, name: found.name, email: found.email, role: found.role },
    token: 'mock-token-' + found.id,
  };
}

/**
 * REPLACE WITH: POST /api/auth/forgot-password
 */
export async function requestPasswordReset({ email }) {
  await delay(400);
  console.log(`[mock] Password reset link "sent" to ${email}`);
  return { message: 'If that email exists in our system, a reset link has been sent.' };
}
