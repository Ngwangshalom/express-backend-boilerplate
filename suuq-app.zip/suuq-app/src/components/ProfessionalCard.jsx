import React from 'react';
import { Card, Avatar, Text, Badge, Button, Stack, Group } from '@mantine/core';
import { IconStarFilled, IconShieldCheck } from '@tabler/icons-react';
import { useNavigate } from 'react-router-dom';

export function ProfessionalCard({ pro }) {
  const navigate = useNavigate();

  return (
    <Card withBorder shadow="sm" padding="lg" w={240} style={{ flex: '0 0 auto' }}>
      <Stack align="center" gap={6}>
        <Avatar src={pro.photo} size={72} radius="xl" />
        <Group gap={4}>
          <Text fw={600} size="sm">{pro.name}</Text>
          {pro.verified && <IconShieldCheck size={15} color="#0F4C5C" />}
        </Group>
        <Text size="xs" c="dimmed" ta="center" lineClamp={1}>{pro.title}</Text>
        <Badge size="sm" variant="light" color="teal">{pro.category}</Badge>

        <Group gap={4} mt={2}>
          <IconStarFilled size={13} color="#D97757" />
          <Text size="xs" fw={500}>{pro.rating}</Text>
          <Text size="xs" c="dimmed">({pro.reviews})</Text>
        </Group>

        <Text fw={700} size="sm" mt={4}>AED {pro.rate.toLocaleString()}/hr</Text>

        <Button
          fullWidth
          size="xs"
          variant="light"
          color="teal"
          mt={6}
          onClick={() => navigate(`/professionals/${pro.id}`)}
        >
          View profile
        </Button>
      </Stack>
    </Card>
  );
}
