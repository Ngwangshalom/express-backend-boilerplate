import React from 'react';
import { Group, Stack, Text, Divider, SimpleGrid, Container } from '@mantine/core';
import { Link } from 'react-router-dom';

const COLUMNS = [
  {
    heading: 'Platform',
    links: [
      { label: 'Browse pros', to: '/browse' },
      { label: 'Post a task', to: '/post-task' },
      { label: 'How it works', to: '/how-it-works' },
    ],
  },
  {
    heading: 'Company',
    links: [
      { label: 'About', to: '/about' },
      { label: 'Contact', to: '/contact' },
    ],
  },
  {
    heading: 'Account',
    links: [
      { label: 'Sign in', to: '/login' },
      { label: 'Join Suuq', to: '/register' },
    ],
  },
];

export function Footer() {
  return (
    <Stack gap={0} style={{ background: '#0F4C5C', color: '#F4EDE4', marginTop: 'auto' }}>
      <Container size="lg" py="xl" w="100%">
        <SimpleGrid cols={{ base: 1, sm: 4 }} spacing="xl">
          <Stack gap="xs">
            <Text fw={800} size="lg" ff="Sora" c="white">suuq</Text>
            <Text size="sm" c="gray.4" maw={240}>
              A marketplace connecting UAE hospitality venues with vetted freelance talent.
            </Text>
          </Stack>

          {COLUMNS.map((col) => (
            <Stack key={col.heading} gap="xs">
              <Text size="sm" fw={600} c="gray.3">{col.heading}</Text>
              {col.links.map((link) => (
                <Text
                  key={link.to}
                  component={Link}
                  to={link.to}
                  size="sm"
                  c="gray.4"
                  style={{ textDecoration: 'none' }}
                >
                  {link.label}
                </Text>
              ))}
            </Stack>
          ))}
        </SimpleGrid>
      </Container>

      <Divider color="teal.8" />

      <Container size="lg" py="md" w="100%">
        <Group justify="space-between">
          <Text size="xs" c="gray.5">© 2026 Suuq — sample project, not affiliated with any real marketplace.</Text>
          <Text size="xs" c="gray.5">Built for interview practice</Text>
        </Group>
      </Container>
    </Stack>
  );
}
