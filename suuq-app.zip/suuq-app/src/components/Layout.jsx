import React from 'react';
import { Outlet } from 'react-router-dom';
import { Box } from '@mantine/core';
import { Header } from './Header';
import { Footer } from './Footer';

export function Layout() {
  return (
    <Box style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />
      <Box style={{ flex: 1 }}>
        <Outlet />
      </Box>
      <Footer />
    </Box>
  );
}
