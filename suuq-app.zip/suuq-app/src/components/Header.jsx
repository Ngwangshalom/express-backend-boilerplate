import React from 'react';
import { Group, Text, Button, Menu, Avatar, Burger, Drawer, Stack, Divider } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { Link, useNavigate } from 'react-router-dom';
import { IconChevronDown, IconLogout, IconUser } from '@tabler/icons-react';
import { useAuth } from '../context/AuthContext';

const NAV_LINKS = [
  { label: 'Browse pros', to: '/browse' },
  { label: 'Post a task', to: '/post-task' },
  { label: 'How it works', to: '/how-it-works' },
];

export function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [opened, { toggle, close }] = useDisclosure(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <Group
      justify="space-between"
      px={{ base: 'md', sm: 'xl' }}
      py="sm"
      style={{
        borderBottom: '1px solid #ECE6DC',
        background: '#FFFFFF',
        position: 'sticky',
        top: 0,
        zIndex: 200,
      }}
    >
      <Link to="/" style={{ textDecoration: 'none' }}>
        <Text fw={800} size="xl" c="teal.6" ff="Sora">
          suuq
        </Text>
      </Link>

      <Group gap="lg" visibleFrom="sm">
        {NAV_LINKS.map((link) => (
          <Text
            key={link.to}
            component={Link}
            to={link.to}
            size="sm"
            fw={500}
            c="dark.6"
            style={{ textDecoration: 'none' }}
          >
            {link.label}
          </Text>
        ))}
      </Group>

      <Group gap="sm" visibleFrom="sm">
        {isAuthenticated ? (
          <Menu shadow="md" width={180} position="bottom-end">
            <Menu.Target>
              <Group gap={6} style={{ cursor: 'pointer' }}>
                <Avatar size="sm" color="teal" radius="xl">
                  {user.name?.[0]?.toUpperCase()}
                </Avatar>
                <Text size="sm" fw={500}>{user.name}</Text>
                <IconChevronDown size={14} />
              </Group>
            </Menu.Target>
            <Menu.Dropdown>
              <Menu.Item leftSection={<IconUser size={14} />} component={Link} to="/dashboard">
                Dashboard
              </Menu.Item>
              <Menu.Item leftSection={<IconLogout size={14} />} color="red" onClick={handleLogout}>
                Log out
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        ) : (
          <>
            <Button component={Link} to="/login" variant="subtle" color="dark" size="sm">
              Sign in
            </Button>
            <Button component={Link} to="/register" color="terracotta.5" size="sm">
              Join Suuq
            </Button>
          </>
        )}
      </Group>

      <Burger opened={opened} onClick={toggle} hiddenFrom="sm" />

      <Drawer opened={opened} onClose={close} hiddenFrom="sm" title="Menu" position="right">
        <Stack gap="md">
          {NAV_LINKS.map((link) => (
            <Text key={link.to} component={Link} to={link.to} onClick={close} fw={500}>
              {link.label}
            </Text>
          ))}
          <Divider />
          {isAuthenticated ? (
            <>
              <Text component={Link} to="/dashboard" onClick={close} fw={500}>
                Dashboard
              </Text>
              <Button color="red" variant="light" onClick={() => { handleLogout(); close(); }}>
                Log out
              </Button>
            </>
          ) : (
            <>
              <Button component={Link} to="/login" onClick={close} variant="subtle">
                Sign in
              </Button>
              <Button component={Link} to="/register" onClick={close} color="terracotta.5">
                Join Suuq
              </Button>
            </>
          )}
        </Stack>
      </Drawer>
    </Group>
  );
}
