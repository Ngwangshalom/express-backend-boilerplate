import React, { useEffect, useState } from 'react';
import { Container, Title, Text, Group, SimpleGrid, Chip, Stack, Center, Loader } from '@mantine/core';
import { useSearchParams } from 'react-router-dom';
import { fetchProfessionals, CATEGORIES } from '../data/professionals';
import { ProfessionalCard } from '../components/ProfessionalCard';

export function BrowsePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeCategory = searchParams.get('category') || 'All';
  const [pros, setPros] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetchProfessionals({ category: activeCategory }).then((data) => {
      setPros(data);
      setLoading(false);
    });
  }, [activeCategory]);

  const setCategory = (cat) => {
    if (cat === 'All') {
      setSearchParams({});
    } else {
      setSearchParams({ category: cat });
    }
  };

  return (
    <Container size="lg" py="xl">
      <Stack gap={4} mb="lg">
        <Title order={1} size={28} ff="Sora">Browse professionals</Title>
        <Text c="dimmed" size="sm">{pros.length} professionals match your filters</Text>
      </Stack>

      <Group gap="xs" mb="xl">
        <Chip checked={activeCategory === 'All'} onChange={() => setCategory('All')} color="teal" variant="filled">
          All
        </Chip>
        {CATEGORIES.map((cat) => (
          <Chip
            key={cat}
            checked={activeCategory === cat}
            onChange={() => setCategory(cat)}
            color="teal"
            variant="filled"
          >
            {cat}
          </Chip>
        ))}
      </Group>

      {loading ? (
        <Center h={200}>
          <Loader color="teal" />
        </Center>
      ) : pros.length === 0 ? (
        <Center h={200}>
          <Text c="dimmed">No professionals found in this category yet.</Text>
        </Center>
      ) : (
        <SimpleGrid cols={{ base: 1, xs: 2, sm: 3, md: 4 }} spacing="md">
          {pros.map((pro) => (
            <ProfessionalCard key={pro.id} pro={pro} />
          ))}
        </SimpleGrid>
      )}
    </Container>
  );
}
