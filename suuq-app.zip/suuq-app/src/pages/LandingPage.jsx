import React, { useEffect, useState } from 'react';
import {
  Container, Title, Text, Button, Group, Stack, SimpleGrid,
  Box, Badge, Card, ThemeIcon, ScrollArea,
} from '@mantine/core';
import { Link } from 'react-router-dom';
import {
  IconShieldCheck, IconClockHour4, IconMapPin, IconArrowRight,
  IconMicrophone2, IconChefHat, IconCalendarEvent, IconSpeakerphone,
  IconTruck, IconPalette,
} from '@tabler/icons-react';
import { fetchProfessionals, CATEGORIES } from '../data/professionals';
import { ProfessionalCard } from '../components/ProfessionalCard';

const CATEGORY_ICONS = {
  'Entertainment': IconMicrophone2,
  'F&B Consulting': IconChefHat,
  'Event Production': IconCalendarEvent,
  'Digital Marketing': IconSpeakerphone,
  'Logistics': IconTruck,
  'Styling & Decor': IconPalette,
};

const CREDENTIALS = [
  { icon: IconShieldCheck, value: '900+', label: 'Verified professionals' },
  { icon: IconClockHour4, value: '< 2 hrs', label: 'Average response time' },
  { icon: IconMapPin, value: '7 cities', label: 'Across the UAE' },
];

export function LandingPage() {
  const [featured, setFeatured] = useState([]);

  useEffect(() => {
    fetchProfessionals().then((data) => setFeatured(data.slice(0, 6)));
  }, []);

  return (
    <Box>
      {/* HERO */}
      <Box style={{ background: '#F4EDE4', borderBottom: '1px solid #ECE6DC' }}>
        <Container size="lg" py={{ base: 50, sm: 80 }}>
          <Stack gap="lg" maw={620}>
            <Badge size="lg" variant="light" color="terracotta" w="fit-content">
              Built for UAE hospitality
            </Badge>
            <Title order={1} size={42} ff="Sora" lh={1.1} c="dark.8">
              Vetted talent, ready before your next shift starts.
            </Title>
            <Text size="lg" c="dark.5">
              Suuq connects venues, planners, and brands with hospitality professionals
              who've already been checked — so you spend less time vetting and more time hosting.
            </Text>
            <Group>
              <Button component={Link} to="/browse" size="md" color="teal.6" rightSection={<IconArrowRight size={16} />}>
                Browse professionals
              </Button>
              <Button component={Link} to="/post-task" size="md" variant="outline" color="dark">
                Post a task
              </Button>
            </Group>
          </Stack>
        </Container>
      </Box>

      {/* CREDENTIAL STRIP */}
      <Container size="lg" py="xl">
        <SimpleGrid cols={{ base: 1, sm: 3 }} spacing="xl">
          {CREDENTIALS.map((c) => (
            <Group key={c.label} gap="md">
              <ThemeIcon size={48} radius="md" variant="light" color="teal">
                <c.icon size={24} />
              </ThemeIcon>
              <Stack gap={0}>
                <Text fw={800} size="xl" ff="Sora">{c.value}</Text>
                <Text size="sm" c="dimmed">{c.label}</Text>
              </Stack>
            </Group>
          ))}
        </SimpleGrid>
      </Container>

      {/* FEATURED PROFESSIONALS */}
      <Container size="lg" py="md">
        <Group justify="space-between" mb="md">
          <Title order={2} size={24} ff="Sora">Featured this week</Title>
          <Text component={Link} to="/browse" size="sm" c="teal.7" fw={500} style={{ textDecoration: 'none' }}>
            See all →
          </Text>
        </Group>
        <ScrollArea type="auto" scrollbarSize={6} offsetScrollbars>
          <Group gap="md" wrap="nowrap" pb="sm">
            {featured.map((pro) => (
              <ProfessionalCard key={pro.id} pro={pro} />
            ))}
          </Group>
        </ScrollArea>
      </Container>

      {/* CATEGORIES */}
      <Box style={{ background: '#FAFAF8' }} py="xl" mt="xl">
        <Container size="lg">
          <Title order={2} size={24} ff="Sora" mb="md">Find talent by category</Title>
          <SimpleGrid cols={{ base: 2, sm: 3, md: 6 }} spacing="md">
            {CATEGORIES.map((cat) => {
              const Icon = CATEGORY_ICONS[cat] || IconShieldCheck;
              return (
                <Card
                  key={cat}
                  component={Link}
                  to={`/browse?category=${encodeURIComponent(cat)}`}
                  withBorder
                  padding="md"
                  style={{ textDecoration: 'none', textAlign: 'center' }}
                >
                  <Stack align="center" gap={6}>
                    <ThemeIcon size={36} radius="xl" variant="light" color="terracotta">
                      <Icon size={20} />
                    </ThemeIcon>
                    <Text size="xs" fw={500} c="dark.7">{cat}</Text>
                  </Stack>
                </Card>
              );
            })}
          </SimpleGrid>
        </Container>
      </Box>

      {/* CTA */}
      <Container size="lg" py={60}>
        <Card style={{ background: '#0F4C5C' }} radius="lg" padding={40}>
          <Stack align="center" gap="sm">
            <Title order={2} size={26} ff="Sora" c="white" ta="center">
              Have a skill venues are looking for?
            </Title>
            <Text c="gray.3" ta="center" maw={460}>
              Join Suuq as a professional and get matched with hospitality clients across the UAE.
            </Text>
            <Button component={Link} to="/register" size="md" color="terracotta.5" mt="sm">
              Join as a professional
            </Button>
          </Stack>
        </Card>
      </Container>
    </Box>
  );
}
