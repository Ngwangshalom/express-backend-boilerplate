import React from 'react';
import { Container, Title, Text, Stack } from '@mantine/core';

export function AboutPage() {
  return (
    <Container size="sm" py={60}>
      <Stack gap="md">
        <Title order={1} size={28} ff="Sora">About Suuq</Title>
        <Text c="dark.6">
          Suuq is a sample marketplace project built to practice a real-world product pattern:
          connecting clients with vetted freelance professionals in the hospitality industry.
        </Text>
        <Text c="dark.6">
          This page, like the rest of the project, uses placeholder content — replace it with
          your own product's story when adapting this template.
        </Text>
      </Stack>
    </Container>
  );
}
