import React, { useState } from 'react';
import {
  Container, Paper, Title, Text, TextInput, PasswordInput, Button,
  Stack, Group, Anchor, Alert, Divider,
} from '@mantine/core';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from '@mantine/form';
import { IconAlertCircle } from '@tabler/icons-react';
import { loginUser } from '../data/auth';
import { useAuth } from '../context/AuthContext';

export function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const form = useForm({
    initialValues: { email: '', password: '' },
    validate: {
      email: (val) => (/^\S+@\S+\.\S+$/.test(val) ? null : 'Enter a valid email'),
      password: (val) => (val.length >= 4 ? null : 'Password is too short'),
    },
  });

  const handleSubmit = async (values) => {
    setError('');
    setLoading(true);
    try {
      const { user } = await loginUser(values);
      login(user);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container size={420} py={80}>
      <Stack gap={4} mb="lg" align="center">
        <Title order={2} ff="Sora">Welcome back</Title>
        <Text c="dimmed" size="sm">Sign in to manage your tasks and bookings.</Text>
      </Stack>

      <Paper withBorder shadow="sm" p="xl" radius="md">
        {error && (
          <Alert icon={<IconAlertCircle size={16} />} color="red" mb="md" radius="md">
            {error}
          </Alert>
        )}
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <Stack gap="md">
            <TextInput label="Email" placeholder="you@example.com" {...form.getInputProps('email')} />
            <PasswordInput label="Password" placeholder="Your password" {...form.getInputProps('password')} />
            <Group justify="flex-end">
              <Anchor component={Link} to="/forgot-password" size="xs" c="teal.7">
                Forgot password?
              </Anchor>
            </Group>
            <Button type="submit" color="teal.6" loading={loading} fullWidth>
              Sign in
            </Button>
          </Stack>
        </form>

        <Divider my="md" label="New to Suuq?" labelPosition="center" />
        <Button component={Link} to="/register" variant="outline" color="dark" fullWidth>
          Create an account
        </Button>
      </Paper>

      <Text size="xs" c="dimmed" ta="center" mt="md">
        This is a demo login using local mock accounts — register first to create one.
      </Text>
    </Container>
  );
}
