import React, { useState } from 'react';
import {
  Container, Paper, Title, Text, TextInput, Button, Stack, Alert,
} from '@mantine/core';
import { Link } from 'react-router-dom';
import { useForm } from '@mantine/form';
import { IconCircleCheck } from '@tabler/icons-react';
import { requestPasswordReset } from '../data/auth';

export function ForgotPasswordPage() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const form = useForm({
    initialValues: { email: '' },
    validate: {
      email: (val) => (/^\S+@\S+\.\S+$/.test(val) ? null : 'Enter a valid email'),
    },
  });

  const handleSubmit = async (values) => {
    setLoading(true);
    await requestPasswordReset(values);
    setLoading(false);
    setSent(true);
  };

  return (
    <Container size={420} py={80}>
      <Stack gap={4} mb="lg" align="center">
        <Title order={2} ff="Sora">Reset your password</Title>
        <Text c="dimmed" size="sm" ta="center">
          Enter the email linked to your account and we'll send you a reset link.
        </Text>
      </Stack>

      <Paper withBorder shadow="sm" p="xl" radius="md">
        {sent ? (
          <Alert icon={<IconCircleCheck size={16} />} color="green" radius="md">
            If that email exists in our system, a reset link has been sent.
          </Alert>
        ) : (
          <form onSubmit={form.onSubmit(handleSubmit)}>
            <Stack gap="md">
              <TextInput label="Email" placeholder="you@example.com" {...form.getInputProps('email')} />
              <Button type="submit" color="teal.6" loading={loading} fullWidth>
                Send reset link
              </Button>
            </Stack>
          </form>
        )}
      </Paper>

      <Text size="sm" ta="center" mt="md">
        <Text component={Link} to="/login" c="teal.7" fw={500} span style={{ textDecoration: 'none' }}>
          Back to sign in
        </Text>
      </Text>
    </Container>
  );
}
