import React from 'react';
import { Container, Title, Text, Stack, SimpleGrid, ThemeIcon, Group } from '@mantine/core';
import { IconSearch, IconMessage, IconCircleCheck } from '@tabler/icons-react';

const STEPS = [
  { icon: IconSearch, title: 'Search', body: 'Browse verified professionals by category, city, or rate.' },
  { icon: IconMessage, title: 'Connect', body: 'Message a professional directly or post a task and let them apply.' },
  { icon: IconCircleCheck, title: 'Confirm', body: 'Agree on scope and rate, then book with confidence — every pro is vetted.' },
];

export function HowItWorksPage() {
  return (
    <Container size="md" py={60}>
      <Stack gap={4} mb="xl" align="center">
        <Title order={1} size={28} ff="Sora" ta="center">How Suuq works</Title>
        <Text c="dimmed" ta="center" maw={460}>
          A simple way to find or offer hospitality talent across the UAE.
        </Text>
      </Stack>

      <SimpleGrid cols={{ base: 1, sm: 3 }} spacing="xl">
        {STEPS.map((step) => (
          <Stack key={step.title} align="center" gap="xs">
            <ThemeIcon size={56} radius="xl" variant="light" color="teal">
              <step.icon size={28} />
            </ThemeIcon>
            <Text fw={700} ff="Sora">{step.title}</Text>
            <Text size="sm" c="dimmed" ta="center">{step.body}</Text>
          </Stack>
        ))}
      </SimpleGrid>
    </Container>
  );
}
