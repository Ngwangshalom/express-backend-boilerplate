import React from 'react';
import { Container, Title, Text, Stack, Card, Group, Avatar, Badge, SimpleGrid } from '@mantine/core';
import { useAuth } from '../context/AuthContext';

export function DashboardPage() {
  const { user } = useAuth();

  return (
    <Container size="lg" py="xl">
      <Group mb="xl">
        <Avatar size={56} radius="xl" color="teal">
          {user?.name?.[0]?.toUpperCase()}
        </Avatar>
        <Stack gap={0}>
          <Title order={2} size={24} ff="Sora">Welcome back, {user?.name}</Title>
          <Badge variant="light" color={user?.role === 'pro' ? 'terracotta' : 'teal'} size="sm">
            {user?.role === 'pro' ? 'Professional account' : 'Client account'}
          </Badge>
        </Stack>
      </Group>

      <SimpleGrid cols={{ base: 1, sm: 3 }} spacing="md">
        <Card withBorder padding="lg">
          <Text size="sm" c="dimmed">Open tasks</Text>
          <Text fw={800} size={28} ff="Sora">3</Text>
        </Card>
        <Card withBorder padding="lg">
          <Text size="sm" c="dimmed">Messages</Text>
          <Text fw={800} size={28} ff="Sora">0</Text>
        </Card>
        <Card withBorder padding="lg">
          <Text size="sm" c="dimmed">Saved profiles</Text>
          <Text fw={800} size={28} ff="Sora">5</Text>
        </Card>
      </SimpleGrid>

      <Text size="xs" c="dimmed" mt="xl">
        This dashboard uses sample data — wire these cards up to your real API once it's ready.
      </Text>
    </Container>
  );
}
