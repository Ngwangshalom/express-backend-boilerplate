import React from 'react';
import { Container, Title, Text, Button, Stack } from '@mantine/core';
import { Link } from 'react-router-dom';

export function NotFoundPage() {
  return (
    <Container size="sm" py={100}>
      <Stack align="center" gap="md">
        <Title order={1} size={48} ff="Sora">404</Title>
        <Text c="dimmed">This page doesn't exist.</Text>
        <Button component={Link} to="/" color="teal.6">Back to home</Button>
      </Stack>
    </Container>
  );
}
