import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Container, Grid, Avatar, Title, Text, Badge, Group, Stack, Button,
  Card, Divider, SimpleGrid, Center, Loader, Image,
} from '@mantine/core';
import { IconStarFilled, IconShieldCheck, IconMapPin, IconArrowLeft } from '@tabler/icons-react';
import { fetchProfessionalById } from '../data/professionals';

export function ProfessionalDetailPage() {
  const { id } = useParams();
  const [pro, setPro] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetchProfessionalById(id).then((data) => {
      setPro(data);
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return (
      <Center h="60vh">
        <Loader color="teal" />
      </Center>
    );
  }

  if (!pro) {
    return (
      <Container size="sm" py={80}>
        <Stack align="center" gap="md">
          <Title order={3}>Profile not found</Title>
          <Text c="dimmed">This professional may have been removed or the link is incorrect.</Text>
          <Button component={Link} to="/browse" variant="light" color="teal">Back to browse</Button>
        </Stack>
      </Container>
    );
  }

  return (
    <Container size="lg" py="xl">
      <Text component={Link} to="/browse" size="sm" c="teal.7" mb="md" style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
        <IconArrowLeft size={14} /> Back to browse
      </Text>

      <Grid gutter="xl">
        <Grid.Col span={{ base: 12, sm: 4 }}>
          <Card withBorder padding="lg">
            <Stack align="center" gap="xs">
              <Avatar src={pro.photo} size={110} radius="xl" />
              <Group gap={4}>
                <Title order={3} size={20}>{pro.name}</Title>
                {pro.verified && <IconShieldCheck size={18} color="#0F4C5C" />}
              </Group>
              <Text c="dimmed" size="sm">{pro.title}</Text>
              <Group gap={4}>
                <IconMapPin size={14} color="#999" />
                <Text size="xs" c="dimmed">{pro.city}, UAE</Text>
              </Group>
              <Group gap={4} mt={4}>
                <IconStarFilled size={15} color="#D97757" />
                <Text fw={600} size="sm">{pro.rating}</Text>
                <Text size="sm" c="dimmed">({pro.reviews} reviews)</Text>
              </Group>
              <Divider w="100%" my="xs" />
              <Text fw={800} size="xl" ff="Sora">AED {pro.rate.toLocaleString()}<Text span size="sm" c="dimmed">/hr</Text></Text>
              <Button fullWidth color="teal.6" mt="sm">Contact {pro.name.split(' ')[0]}</Button>
              <Button fullWidth variant="outline" color="dark">Save profile</Button>
            </Stack>
          </Card>
        </Grid.Col>

        <Grid.Col span={{ base: 12, sm: 8 }}>
          <Stack gap="xl">
            <Stack gap="xs">
              <Title order={4}>About</Title>
              <Text c="dark.6">{pro.bio}</Text>
            </Stack>

            <Stack gap="xs">
              <Title order={4}>Skills</Title>
              <Group gap="xs">
                {pro.skills.map((skill) => (
                  <Badge key={skill} variant="light" color="teal" size="lg">{skill}</Badge>
                ))}
              </Group>
            </Stack>

            {pro.gallery?.length > 0 && (
              <Stack gap="xs">
                <Title order={4}>Past work</Title>
                <SimpleGrid cols={{ base: 1, sm: 2 }} spacing="md">
                  {pro.gallery.map((src) => (
                    <Image key={src} src={src} radius="md" h={180} fit="cover" />
                  ))}
                </SimpleGrid>
              </Stack>
            )}
          </Stack>
        </Grid.Col>
      </Grid>
    </Container>
  );
}
