import React, { useState } from 'react';
import {
  Container, Title, Text, TextInput, Textarea, NumberInput, Select,
  Button, Stack, Paper, Alert,
} from '@mantine/core';
import { useForm } from '@mantine/form';
import { IconCircleCheck } from '@tabler/icons-react';
import { postTask, CATEGORIES } from '../data/professionals';

export function PostTaskPage() {
  const [submitted, setSubmitted] = useState(null);
  const [loading, setLoading] = useState(false);

  const form = useForm({
    initialValues: { title: '', description: '', budget: 1000, category: CATEGORIES[0], city: '' },
    validate: {
      title: (val) => (val.trim().length >= 3 ? null : 'Give your task a title'),
      description: (val) => (val.trim().length >= 10 ? null : 'Add a bit more detail'),
      city: (val) => (val.trim() ? null : 'Enter a city'),
    },
  });

  const handleSubmit = async (values) => {
    setLoading(true);
    const result = await postTask(values);
    setSubmitted(result);
    setLoading(false);
    form.reset();
  };

  return (
    <Container size={560} py={60}>
      <Stack gap={4} mb="lg">
        <Title order={1} size={28} ff="Sora">Post a task</Title>
        <Text c="dimmed" size="sm">Describe what you need — verified professionals will reach out.</Text>
      </Stack>

      {submitted && (
        <Alert icon={<IconCircleCheck size={16} />} color="green" mb="md" radius="md">
          Task posted: "{submitted.title}" — professionals can now apply.
        </Alert>
      )}

      <Paper withBorder shadow="sm" p="xl" radius="md">
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <Stack gap="md">
            <TextInput
              label="Task title"
              placeholder="e.g. DJ for rooftop launch event"
              {...form.getInputProps('title')}
            />
            <Textarea
              label="Description"
              placeholder="Share details — date, venue type, what you're looking for..."
              minRows={4}
              {...form.getInputProps('description')}
            />
            <Select
              label="Category"
              data={CATEGORIES}
              {...form.getInputProps('category')}
            />
            <TextInput
              label="City"
              placeholder="e.g. Dubai"
              {...form.getInputProps('city')}
            />
            <NumberInput
              label="Budget (AED)"
              min={0}
              step={100}
              {...form.getInputProps('budget')}
            />
            <Button type="submit" color="teal.6" loading={loading} fullWidth>
              Post task
            </Button>
          </Stack>
        </form>
      </Paper>
    </Container>
  );
}
