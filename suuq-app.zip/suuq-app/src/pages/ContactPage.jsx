import React, { useState } from 'react';
import { Container, Title, Text, TextInput, Textarea, Button, Stack, Paper, Alert } from '@mantine/core';
import { useForm } from '@mantine/form';
import { IconCircleCheck } from '@tabler/icons-react';

export function ContactPage() {
  const [sent, setSent] = useState(false);

  const form = useForm({
    initialValues: { name: '', email: '', message: '' },
    validate: {
      name: (val) => (val.trim() ? null : 'Enter your name'),
      email: (val) => (/^\S+@\S+\.\S+$/.test(val) ? null : 'Enter a valid email'),
      message: (val) => (val.trim().length >= 5 ? null : 'Message is too short'),
    },
  });

  const handleSubmit = (values) => {
    console.log('[mock] Contact form submitted:', values);
    setSent(true);
    form.reset();
  };

  return (
    <Container size={480} py={60}>
      <Stack gap={4} mb="lg">
        <Title order={1} size={28} ff="Sora">Contact us</Title>
        <Text c="dimmed" size="sm">Questions about Suuq? Send us a message.</Text>
      </Stack>

      {sent && (
        <Alert icon={<IconCircleCheck size={16} />} color="green" mb="md" radius="md">
          Thanks — we'll get back to you shortly.
        </Alert>
      )}

      <Paper withBorder shadow="sm" p="xl" radius="md">
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <Stack gap="md">
            <TextInput label="Name" {...form.getInputProps('name')} />
            <TextInput label="Email" {...form.getInputProps('email')} />
            <Textarea label="Message" minRows={4} {...form.getInputProps('message')} />
            <Button type="submit" color="teal.6" fullWidth>Send message</Button>
          </Stack>
        </form>
      </Paper>
    </Container>
  );
}
