import React, { useState } from 'react';
import {
  Container, Paper, Title, Text, TextInput, PasswordInput, Button,
  Stack, Alert, SegmentedControl,
} from '@mantine/core';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from '@mantine/form';
import { IconAlertCircle } from '@tabler/icons-react';
import { registerUser } from '../data/auth';
import { useAuth } from '../context/AuthContext';

export function RegisterPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const form = useForm({
    initialValues: { name: '', email: '', password: '', role: 'client' },
    validate: {
      name: (val) => (val.trim().length >= 2 ? null : 'Enter your name'),
      email: (val) => (/^\S+@\S+\.\S+$/.test(val) ? null : 'Enter a valid email'),
      password: (val) => (val.length >= 4 ? null : 'Password must be at least 4 characters'),
    },
  });

  const handleSubmit = async (values) => {
    setError('');
    setLoading(true);
    try {
      const { user } = await registerUser(values);
      login(user);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container size={420} py={80}>
      <Stack gap={4} mb="lg" align="center">
        <Title order={2} ff="Sora">Join Suuq</Title>
        <Text c="dimmed" size="sm">Create an account to get started.</Text>
      </Stack>

      <Paper withBorder shadow="sm" p="xl" radius="md">
        {error && (
          <Alert icon={<IconAlertCircle size={16} />} color="red" mb="md" radius="md">
            {error}
          </Alert>
        )}
        <form onSubmit={form.onSubmit(handleSubmit)}>
          <Stack gap="md">
            <SegmentedControl
              fullWidth
              color="teal"
              data={[
                { label: 'I need a professional', value: 'client' },
                { label: "I'm a professional", value: 'pro' },
              ]}
              {...form.getInputProps('role')}
            />
            <TextInput label="Full name" placeholder="Your name" {...form.getInputProps('name')} />
            <TextInput label="Email" placeholder="you@example.com" {...form.getInputProps('email')} />
            <PasswordInput label="Password" placeholder="Create a password" {...form.getInputProps('password')} />
            <Button type="submit" color="teal.6" loading={loading} fullWidth>
              Create account
            </Button>
          </Stack>
        </form>
      </Paper>

      <Text size="sm" ta="center" mt="md">
        Already have an account?{' '}
        <Text component={Link} to="/login" c="teal.7" fw={500} span style={{ textDecoration: 'none' }}>
          Sign in
        </Text>
      </Text>
    </Container>
  );
}
