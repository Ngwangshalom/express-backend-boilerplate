# Suuq — Hospitality Marketplace (Sample Project)

A complete, working frontend for a hospitality freelancer marketplace — landing page, browse/listings, professional profiles, auth (login/register/forgot password), and a protected dashboard. Built with **Vite + React + Mantine + React Router**, running entirely on **mock data** so it works standalone with zero backend setup. Swap in your real API in a few clearly marked places when ready.

> This is an original sample project for practice/learning — not a clone of any real company's site, design, or copy.

## Stack

- **Vite** — build tool & dev server
- **React 18**
- **Mantine v7** — UI components (`@mantine/core`, `@mantine/hooks`, `@mantine/form`)
- **React Router v6** (`createBrowserRouter` / data router API)
- **Tabler Icons** — icon set used throughout

## Folder structure

```
suuq-app/
├── src/
│   ├── components/
│   │   ├── Header.jsx           # Top nav, auth-aware (shows login/register or user menu)
│   │   ├── Footer.jsx           # Site footer with link columns
│   │   ├── Layout.jsx           # Wraps pages with Header + Footer via <Outlet />
│   │   ├── ProfessionalCard.jsx # Reusable listing card (used on landing + browse pages)
│   │   └── ProtectedRoute.jsx   # Redirects to /login if not authenticated
│   ├── context/
│   │   └── AuthContext.jsx      # Shares login state app-wide, persists to localStorage
│   ├── data/
│   │   ├── professionals.js     # MOCK DATA + functions to fetch listings/tasks
│   │   └── auth.js              # MOCK AUTH functions (register/login/forgot password)
│   ├── pages/
│   │   ├── LandingPage.jsx
│   │   ├── BrowsePage.jsx
│   │   ├── ProfessionalDetailPage.jsx
│   │   ├── PostTaskPage.jsx
│   │   ├── LoginPage.jsx
│   │   ├── RegisterPage.jsx
│   │   ├── ForgotPasswordPage.jsx
│   │   ├── DashboardPage.jsx    # Protected — requires login
│   │   ├── HowItWorksPage.jsx
│   │   ├── AboutPage.jsx
│   │   ├── ContactPage.jsx
│   │   └── NotFoundPage.jsx
│   ├── styles/
│   │   └── theme.js             # Mantine theme — colors, fonts, component defaults
│   ├── config.js                # API_BASE_URL — the one place backend URL is set
│   ├── App.jsx                  # Wraps MantineProvider + AuthProvider + Router
│   ├── Router.jsx               # All routes defined here
│   └── main.jsx                 # Entry point
├── .env.example
├── index.html
├── package.json
├── postcss.config.js
└── vite.config.js
```

## Setup

```bash
npm install
npm run dev
```

Visit `http://localhost:5173`. That's it — no `.env`, no database, no backend required to explore the full app. Every page works immediately on mock data.

## Pages included

| Route | Page | Notes |
|---|---|---|
| `/` | Landing page | Hero, credential stats, featured pros, categories, CTA |
| `/browse` | Browse/listings | Category filter (synced to URL via `?category=`), grid of cards |
| `/professionals/:id` | Profile detail | Bio, skills, gallery, contact button |
| `/post-task` | Post a task | Form → calls `postTask()` mock function |
| `/login` | Login | Validates against mock accounts created via Register |
| `/register` | Register | Creates a mock account (role: client or professional) |
| `/forgot-password` | Forgot password | Simulates sending a reset email |
| `/dashboard` | Dashboard | **Protected** — redirects to `/login` if not signed in |
| `/how-it-works` | How it works | 3-step explainer |
| `/about`, `/contact` | Static pages | Linked from footer |
| `*` | 404 | Catch-all |

## How the mock data works

Everything lives in two files:

- **`src/data/professionals.js`** — sample listings + `fetchProfessionals()`, `fetchProfessionalById()`, `postTask()`
- **`src/data/auth.js`** — `registerUser()`, `loginUser()`, `requestPasswordReset()` (accounts are stored in `localStorage` so register → login actually works end-to-end)

Every function returns a `Promise` (with a small artificial delay), matching the shape a real `fetch()` call would return. This means pages already handle loading states correctly.

## Connecting your real backend

This is the only part you need to touch:

1. Open **`src/config.js`** and confirm `API_BASE_URL` points to your backend (defaults to `http://localhost:5000`, override via `.env`):
   ```bash
   cp .env.example .env
   # edit VITE_API_BASE_URL if your backend runs elsewhere
   ```

2. In **`src/data/professionals.js`**, replace each function body with a real fetch. Example:
   ```js
   export async function fetchProfessionals({ category } = {}) {
     const url = category && category !== 'All'
       ? `${API_BASE_URL}/api/professionals?category=${encodeURIComponent(category)}`
       : `${API_BASE_URL}/api/professionals`;
     const res = await fetch(url);
     if (!res.ok) throw new Error('Failed to fetch professionals');
     return res.json();
   }
   ```

3. Do the same in **`src/data/auth.js`** for `registerUser`, `loginUser`, `requestPasswordReset` — point them at your real `/api/auth/...` endpoints.

Because every page imports these functions (not raw data), **no page component needs to change** — only the two files in `src/data/` do.

## Notes

- Auth here is intentionally simple (localStorage-based mock) — replace with real JWT/session handling from your backend when wiring it in.
- The Mantine theme (colors, fonts) lives in `src/styles/theme.js` — change values there to re-skin the whole app from one place.
- No tests included — this is a fast-build starting point, not a production template.

## License

MIT — use freely for personal projects, interviews, or as a learning reference.
